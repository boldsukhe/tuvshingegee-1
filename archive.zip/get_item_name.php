<?php

require_once "db_connect.php";

$sql = "SELECT utga FROM buleg WHERE buleg_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $buleg_id);
$stmt->execute();
$result = $stmt->get_result();

$data = $result->fetch_assoc();

if ($data) {
    echo json_encode(["utga" => $data['utga']], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["error" => "No data found for buleg_id: $buleg_id"]);
}

$conn->close();
?>
