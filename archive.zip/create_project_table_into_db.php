<?php
require "db_connect.php";

// Check if the project name was passed
if (isset($_GET['projectName']) && !empty(trim($_GET['projectName']))) {
    // Sanitize the name: allow only letters, numbers, and underscores
    $rawProjectName = $_GET['projectName'];
    $projectName = preg_replace('/[^a-zA-Z0-9_]/', '', str_replace(' ', '_', $rawProjectName));

    if ($projectName === '') {
        die("Error: Project name after sanitization is empty or invalid.");
    }

    $sql = "CREATE TABLE `$projectName` (
        project_id INT AUTO_INCREMENT PRIMARY KEY,
        group_number INT NOT NULL,
        name VARCHAR(30) NOT NULL,
        quantity INT NOT NULL,
        unit_cost INT NOT NULL,
        total_cost INT NOT NULL,
        start_date VARCHAR(30) NOT NULL,
        end_date VARCHAR(30) NOT NULL
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Table '$projectName' created successfully.";
    } else {
        echo "Error creating table: " . $conn->error;
    }

} else {
    echo "Error: No valid project name provided in the URL.";
}

$conn->close();
?>
