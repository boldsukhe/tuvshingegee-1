<?php
header('Content-Type: application/json'); // Ensure proper JSON response

require_once "db_connect.php";

$sql = "SELECT buleg_id FROM buleg";
$result = $conn->query($sql);

$groups = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $groups[] = $row;
    }
}

echo json_encode($groups, JSON_UNESCAPED_UNICODE); // Ensures UTF-8 characters work

$conn->close();
?>

