<?php
require "db_connect.php";

$sql = "SELECT group_name, name, quantity, start_date, end_date, id FROM excel_data";
$result = $conn->query($sql);
?>

<!-- Step 3: Display data in HTML -->
<!DOCTYPE html>
<html>
<head>
    <title>Төсөл харах</title>
</head>
<style>
    
body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #3498db;
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e1f5fe;
        }

        a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
        </style>
<body>
    <h2>Зүүн хараа төсөл</h2>
    <table border="1">
        <tr>
            <th>Бүлэг</th>
            <th>Нэр</th>
            <th>Тоо хэмжээ</th>
            <th>Эхлэх хугацаа</th>
            <th>Дуусах хугацаа</th>
        </tr>

        <?php
        // Step 4: Output data into table rows
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                //echo "<td><a href='ded_buleg.php?group=" . urlencode($row["group_name"]) . "'>" . htmlspecialchars($row["group_name"]) . "</a></td>";
                //echo "<td>" . htmlspecialchars($row["group_name"]) . "</td>";
                echo "<td><a href='buleg_zadargaa.php?group=" . urlencode($row["group_name"]) . "&id=" . urlencode($row["id"]) . "'>" . htmlspecialchars($row["group_name"]) . "</a></td>";
                echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["quantity"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["start_date"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["end_date"]) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No results found</td></tr>";
        }

        // Close the connection
        $conn->close();
        ?>
    </table>
</body>
</html>
